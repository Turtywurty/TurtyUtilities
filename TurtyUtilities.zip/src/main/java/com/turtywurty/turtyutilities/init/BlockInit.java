package com.turtywurty.turtyutilities.init;

import java.util.ArrayList;
import java.util.List;

import com.turtywurty.turtyutilities.objects.blocks.BlockBase;
import com.turtywurty.turtyutilities.objects.blocks.BlockOres;
import com.turtywurty.turtyutilities.objects.blocks.BlockTomatoPlant;
import com.turtywurty.turtyutilities.objects.blocks.CopperStairs;
import com.turtywurty.turtyutilities.objects.blocks.TinStairs;
import com.turtywurty.turtyutilities.objects.blocks.coloured.BlockBlack;
import com.turtywurty.turtyutilities.objects.blocks.coloured.BlockBlue;
import com.turtywurty.turtyutilities.objects.blocks.coloured.BlockBrown;
import com.turtywurty.turtyutilities.objects.blocks.coloured.BlockDarkBlue;
import com.turtywurty.turtyutilities.objects.blocks.coloured.BlockDarkGreen;
import com.turtywurty.turtyutilities.objects.blocks.coloured.BlockDarkGrey;
import com.turtywurty.turtyutilities.objects.blocks.coloured.BlockGreen;
import com.turtywurty.turtyutilities.objects.blocks.coloured.BlockGrey;
import com.turtywurty.turtyutilities.objects.blocks.coloured.BlockLightBlue;
import com.turtywurty.turtyutilities.objects.blocks.coloured.BlockLightGrey;
import com.turtywurty.turtyutilities.objects.blocks.coloured.BlockLightPink;
import com.turtywurty.turtyutilities.objects.blocks.coloured.BlockLimeGreen;
import com.turtywurty.turtyutilities.objects.blocks.coloured.BlockOrange;
import com.turtywurty.turtyutilities.objects.blocks.coloured.BlockPink;
import com.turtywurty.turtyutilities.objects.blocks.coloured.BlockPurple;
import com.turtywurty.turtyutilities.objects.blocks.coloured.BlockRed;
import com.turtywurty.turtyutilities.objects.blocks.coloured.BlockWhite;
import com.turtywurty.turtyutilities.objects.blocks.coloured.BlockYellow;
import com.turtywurty.turtyutilities.objects.items.food.PizzaBlock;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class BlockInit 
{
public static final List<Block> BLOCKS = new ArrayList<Block>();
	
	public static final Block TIN_BLOCK = new BlockBase("tin_block", Material.IRON);
	public static final Block TOMATO_PLANT = new BlockTomatoPlant("tomato_plant");
	public static final Block TIN_STAIRS = new TinStairs("tin_stairs", TIN_BLOCK.getDefaultState());
	public static final Block COPPER_BLOCK = new BlockBase("copper_block", Material.IRON);
	public static final Block COPPER_STAIRS = new CopperStairs("copper_stairs", COPPER_BLOCK.getDefaultState(), Material.IRON);
	public static final Block RUBY_BLOCK = new BlockBase("ruby_block", Material.IRON);
	public static final Block SAPPHIRE_BLOCK = new BlockBase("sapphire_block", Material.IRON);
	public static final Block AMETHYST_BLOCK = new BlockBase("amethyst_block", Material.IRON);
	public static final Block PIZZA_BLOCK = new PizzaBlock("pizza_block", Material.CAKE);
	
	//Ores V V V
	public static final Block ORE_OVERWORLD = new BlockOres("ore_overworld", "overworld");
	public static final Block ORE_NETHER = new BlockOres("ore_nether", "nether");
	public static final Block ORE_END = new BlockOres("ore_end", "end");
	
	//Coloured Blocks V V V 
	public static final Block WHITE_BLOCK = new BlockWhite("white_block", Material.CLOTH);
	public static final Block BLACK_BLOCK = new BlockBlack("black_block", Material.CLOTH);
	public static final Block BLUE_BLOCK = new BlockBlue("blue_block", Material.CLOTH);
	public static final Block DARKBLUE_BLOCK = new BlockDarkBlue("darkblue_block", Material.CLOTH);
	public static final Block DARKGREEN_BLOCK = new BlockDarkGreen("darkgreen_block", Material.CLOTH);
	public static final Block DARKGREY_BLOCK = new BlockDarkGrey("darkgrey_block", Material.CLOTH);
	public static final Block GREEN_BLOCK = new BlockGreen("green_block", Material.CLOTH);
	public static final Block GREY_BLOCK = new BlockGrey("grey_block", Material.CLOTH);
	public static final Block LIGHTBLUE_BLOCK = new BlockLightBlue("lightblue_block", Material.CLOTH);
	public static final Block LIGHTGREY_BLOCK = new BlockLightGrey("lightgrey_block", Material.CLOTH);
	public static final Block LIGHTPINK_BLOCK = new BlockLightPink("lightpink_block", Material.CLOTH);
	public static final Block LIMEGREEN_BLOCK = new BlockLimeGreen("limegreen_block", Material.CLOTH);
	public static final Block ORANGE_BLOCK = new BlockOrange("orange_block", Material.CLOTH);
	public static final Block PINK_BLOCK = new BlockPink("pink_block", Material.CLOTH);
	public static final Block PURPLE_BLOCK = new BlockPurple("purple_block", Material.CLOTH);
	public static final Block RED_BLOCK = new BlockRed("red_block", Material.CLOTH);
	public static final Block YELLOW_BLOCK = new BlockYellow("yellow_block", Material.CLOTH);
	public static final Block BROWN_BLOCK = new BlockBrown("brown_block", Material.CLOTH);
}
