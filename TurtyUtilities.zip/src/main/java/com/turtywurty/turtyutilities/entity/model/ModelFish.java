package com.turtywurty.turtyutilities.entity.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

//ModelFish - TurtyWurty

public class ModelFish extends ModelBase 
{
    public ModelRenderer Bottom;
    public ModelRenderer Right;
    public ModelRenderer Left;
    public ModelRenderer Front;
    public ModelRenderer Back;
    public ModelRenderer Tail;
    public ModelRenderer Bottom_1;

    //Sets Sizes, Offsets, Rotation etc.
    public ModelFish() 
    {
        this.textureWidth = 64;
        this.textureHeight = 64;
        this.Left = new ModelRenderer(this, 36, 0);
        this.Left.setRotationPoint(-2.0F, 18.0F, -5.0F);
        this.Left.addBox(0.0F, 0.0F, 0.0F, 1, 5, 10, 0.0F);
        this.Tail = new ModelRenderer(this, 38, 0);
        this.Tail.setRotationPoint(-0.5F, 21.0F, 6.0F);
        this.Tail.addBox(0.0F, 0.0F, 0.0F, 1, 3, 2, 0.0F);
        this.setRotateAngle(Tail, 1.5707963267948966F, 0.0F, 0.0F);
        this.Bottom = new ModelRenderer(this, 0, 0);
        this.Bottom.setRotationPoint(-1.0F, 23.0F, 5.0F);
        this.Bottom.addBox(0.0F, 0.0F, 0.0F, 10, 1, 2, 0.0F);
        this.setRotateAngle(Bottom, 0.0F, 1.5707963267948966F, 0.0F);
        this.Back = new ModelRenderer(this, 32, 0);
        this.Back.setRotationPoint(-1.0F, 18.0F, 5.0F);
        this.Back.addBox(0.0F, 0.0F, 0.0F, 2, 5, 1, 0.0F);
        this.Right = new ModelRenderer(this, 14, 0);
        this.Right.setRotationPoint(1.0F, 18.0F, -5.0F);
        this.Right.addBox(0.0F, 0.0F, 0.0F, 1, 5, 10, 0.0F);
        this.Bottom_1 = new ModelRenderer(this, 0, 3);
        this.Bottom_1.setRotationPoint(-1.0F, 17.0F, 5.0F);
        this.Bottom_1.addBox(0.0F, 0.0F, 0.0F, 10, 1, 2, 0.0F);
        this.setRotateAngle(Bottom_1, 0.0F, 1.5707963267948966F, 0.0F);
        this.Front = new ModelRenderer(this, 26, 0);
        this.Front.setRotationPoint(-1.0F, 18.0F, -6.0F);
        this.Front.addBox(0.0F, 0.0F, 0.0F, 2, 5, 1, 0.0F);
    }

    //Renders the parts.
    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) 
    { 
        this.Left.render(f5);
        this.Tail.render(f5);
        this.Bottom.render(f5);
        this.Back.render(f5);
        this.Right.render(f5);
        this.Bottom_1.render(f5);
        this.Front.render(f5);
    }


    //Sets Rotation.
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) 
    {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
