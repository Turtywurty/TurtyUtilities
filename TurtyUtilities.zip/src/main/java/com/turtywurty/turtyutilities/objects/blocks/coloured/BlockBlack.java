package com.turtywurty.turtyutilities.objects.blocks.coloured;

import com.turtywurty.turtyutilities.Main;
import com.turtywurty.turtyutilities.init.BlockInit;
import com.turtywurty.turtyutilities.init.ItemInit;
import com.turtywurty.turtyutilities.util.interfaces.IHasModel;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;

public class BlockBlack extends Block implements IHasModel
{
	public BlockBlack(String name, Material material)
	{
		super(material);
		setUnlocalizedName(name);
		setRegistryName(name);
		setCreativeTab(Main.TURTYUTILITIESTAB);
		
		BlockInit.BLOCKS.add(this);
		ItemInit.ITEMS.add(new ItemBlock(this).setRegistryName(this.getRegistryName()));
	}
	
	@Override
	public void registerModels() 
	{
		Main.proxy.registerItemRenderer(Item.getItemFromBlock(this), 0, "inventory");
	}
}
