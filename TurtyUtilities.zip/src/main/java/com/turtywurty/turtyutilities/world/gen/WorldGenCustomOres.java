package com.turtywurty.turtyutilities.world.gen;

import java.util.Random;

import com.turtywurty.turtyutilities.init.BlockInit;
import com.turtywurty.turtyutilities.objects.blocks.BlockOres;
import com.turtywurty.turtyutilities.objects.blocks.BlockOres;
import com.turtywurty.turtyutilities.util.handlers.EnumHandler;

import net.minecraft.block.state.pattern.BlockMatcher;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraft.world.gen.feature.WorldGenMinable;
import net.minecraft.world.gen.feature.WorldGenerator;
import net.minecraftforge.fml.common.IWorldGenerator;

public class WorldGenCustomOres implements IWorldGenerator

{
	private WorldGenerator ore_nether_tin, ore_overworld_tin, ore_end_tin;
	private WorldGenerator ore_nether_ruby, ore_overworld_ruby, ore_end_ruby;
	private WorldGenerator ore_nether_copper, ore_overworld_copper, ore_end_copper;
	private WorldGenerator ore_nether_sapphire, ore_overworld_sapphire, ore_end_sapphire;
	private WorldGenerator ore_nether_amethyst, ore_overworld_amethyst, ore_end_amethyst;
	private WorldGenerator ore_nether_silver, ore_overworld_silver, ore_end_silver;

	public WorldGenCustomOres() 
	{
		ore_nether_tin = new WorldGenMinable(BlockInit.ORE_NETHER.getDefaultState().withProperty(BlockOres.VARIANT, EnumHandler.EnumType.TIN), 9, BlockMatcher.forBlock(Blocks.NETHERRACK));
		ore_overworld_tin = new WorldGenMinable(BlockInit.ORE_OVERWORLD.getDefaultState().withProperty(BlockOres.VARIANT, EnumHandler.EnumType.TIN), 9, BlockMatcher.forBlock(Blocks.STONE));
		ore_end_tin = new WorldGenMinable(BlockInit.ORE_END.getDefaultState().withProperty(BlockOres.VARIANT, EnumHandler.EnumType.TIN), 9, BlockMatcher.forBlock(Blocks.END_STONE));

		ore_nether_ruby = new WorldGenMinable(BlockInit.ORE_NETHER.getDefaultState().withProperty(BlockOres.VARIANT, EnumHandler.EnumType.RUBY), 9, BlockMatcher.forBlock(Blocks.NETHERRACK));
		ore_overworld_ruby = new WorldGenMinable(BlockInit.ORE_OVERWORLD.getDefaultState().withProperty(BlockOres.VARIANT, EnumHandler.EnumType.RUBY), 9, BlockMatcher.forBlock(Blocks.STONE));
		ore_end_ruby = new WorldGenMinable(BlockInit.ORE_END.getDefaultState().withProperty(BlockOres.VARIANT, EnumHandler.EnumType.RUBY), 9, BlockMatcher.forBlock(Blocks.END_STONE));
		
		ore_nether_copper = new WorldGenMinable(BlockInit.ORE_NETHER.getDefaultState().withProperty(BlockOres.VARIANT, EnumHandler.EnumType.COPPER), 9, BlockMatcher.forBlock(Blocks.NETHERRACK));
		ore_overworld_copper = new WorldGenMinable(BlockInit.ORE_OVERWORLD.getDefaultState().withProperty(BlockOres.VARIANT, EnumHandler.EnumType.COPPER), 9, BlockMatcher.forBlock(Blocks.STONE));
		ore_end_copper = new WorldGenMinable(BlockInit.ORE_END.getDefaultState().withProperty(BlockOres.VARIANT, EnumHandler.EnumType.COPPER), 9, BlockMatcher.forBlock(Blocks.END_STONE));
		
		ore_nether_sapphire = new WorldGenMinable(BlockInit.ORE_NETHER.getDefaultState().withProperty(BlockOres.VARIANT, EnumHandler.EnumType.SAPPHIRE), 9, BlockMatcher.forBlock(Blocks.NETHERRACK));
		ore_overworld_sapphire = new WorldGenMinable(BlockInit.ORE_OVERWORLD.getDefaultState().withProperty(BlockOres.VARIANT, EnumHandler.EnumType.SAPPHIRE), 9, BlockMatcher.forBlock(Blocks.STONE));
		ore_end_sapphire = new WorldGenMinable(BlockInit.ORE_END.getDefaultState().withProperty(BlockOres.VARIANT, EnumHandler.EnumType.SAPPHIRE), 9, BlockMatcher.forBlock(Blocks.END_STONE));
		
		ore_nether_amethyst = new WorldGenMinable(BlockInit.ORE_NETHER.getDefaultState().withProperty(BlockOres.VARIANT, EnumHandler.EnumType.AMETHYST), 9, BlockMatcher.forBlock(Blocks.NETHERRACK));
		ore_overworld_amethyst = new WorldGenMinable(BlockInit.ORE_OVERWORLD.getDefaultState().withProperty(BlockOres.VARIANT, EnumHandler.EnumType.AMETHYST), 9, BlockMatcher.forBlock(Blocks.STONE));
		ore_end_amethyst = new WorldGenMinable(BlockInit.ORE_END.getDefaultState().withProperty(BlockOres.VARIANT, EnumHandler.EnumType.AMETHYST), 9, BlockMatcher.forBlock(Blocks.END_STONE));
		
		ore_nether_silver = new WorldGenMinable(BlockInit.ORE_NETHER.getDefaultState().withProperty(BlockOres.VARIANT, EnumHandler.EnumType.SILVER), 9, BlockMatcher.forBlock(Blocks.NETHERRACK));
		ore_overworld_silver = new WorldGenMinable(BlockInit.ORE_OVERWORLD.getDefaultState().withProperty(BlockOres.VARIANT, EnumHandler.EnumType.SILVER), 9, BlockMatcher.forBlock(Blocks.STONE));
		ore_end_silver = new WorldGenMinable(BlockInit.ORE_END.getDefaultState().withProperty(BlockOres.VARIANT, EnumHandler.EnumType.SILVER), 9, BlockMatcher.forBlock(Blocks.END_STONE));
	}

	@Override
	public void generate(Random random, int chunkX, int chunkZ, World world, IChunkGenerator chunkGenerator, IChunkProvider chunkProvider) 
	{
		switch(world.provider.getDimension())
		{
		case -1:

			runGenerator(ore_nether_ruby, world, random, chunkX, chunkZ, 15, 0, 256);
			runGenerator(ore_nether_tin, world, random, chunkX, chunkZ, 30, 0, 256);
			runGenerator(ore_nether_copper, world, random, chunkX, chunkZ, 30, 0, 256);
			runGenerator(ore_nether_sapphire, world, random, chunkX, chunkZ, 15, 0, 256);
			runGenerator(ore_nether_amethyst, world, random, chunkX, chunkZ, 15, 0, 256);
			runGenerator(ore_nether_silver, world, random, chunkX, chunkZ, 30, 0, 256);
			
			break;

		case 0:

			runGenerator(ore_overworld_ruby, world, random, chunkX, chunkZ, 3, 0, 40);
			runGenerator(ore_overworld_tin, world, random, chunkX, chunkZ, 30, 0, 256);
			runGenerator(ore_overworld_copper, world, random, chunkX, chunkZ, 30, 0, 256);
			runGenerator(ore_overworld_sapphire, world, random, chunkX, chunkZ, 6, 0, 30);
			runGenerator(ore_overworld_amethyst, world, random, chunkX, chunkZ, 13, 0, 15);
			runGenerator(ore_overworld_silver, world, random, chunkX, chunkZ, 30, 0, 256);

			break;

		case 1:

			runGenerator(ore_end_ruby, world, random, chunkX, chunkZ, 2, 0, 256);
			runGenerator(ore_end_tin, world, random, chunkX, chunkZ, 30, 0, 256);
			runGenerator(ore_end_copper, world, random, chunkX, chunkZ, 30, 0, 256);
			runGenerator(ore_end_sapphire, world, random, chunkX, chunkZ, 2, 0, 256);
			runGenerator(ore_end_amethyst, world, random, chunkX, chunkZ, 1, 0, 256);
			runGenerator(ore_end_silver, world, random, chunkX, chunkZ, 30, 0, 256);
		}
	}

	private void runGenerator(WorldGenerator gen, World world, Random rand, int chunkX, int chunkZ, int chance, int minHeight, int maxHeight)
	{
		if(minHeight > maxHeight || minHeight < 0 || maxHeight > 256) throw new IllegalArgumentException("Ore generated out of bounds!!");

		int heightDiff = maxHeight - minHeight + 1;
		for(int i = 0; i < chance; i++)
		{
			int x = chunkX * 16 + rand.nextInt(16);
			int y = minHeight + rand.nextInt(heightDiff);
			int z = chunkZ * 16 + rand.nextInt(16);

			gen.generate(world, rand, new BlockPos(x,y,z));
		}
	}
}
