package com.turtywurty.turtyutilities.util.interfaces;

import net.minecraft.item.ItemStack;

public interface IMetaName 
{
	public String getSpecialName(ItemStack stack);
}
