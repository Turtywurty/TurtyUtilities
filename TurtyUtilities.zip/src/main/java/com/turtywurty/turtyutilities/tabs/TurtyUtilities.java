package com.turtywurty.turtyutilities.tabs;

import com.turtywurty.turtyutilities.init.ItemInit;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;

public class TurtyUtilities extends CreativeTabs
{
	public TurtyUtilities(String label) 
	{ 
		super("turtyutilitiestab");
		this.setBackgroundImageName("turtyutilitiestab.png");
	}

	@Override
	public ItemStack getTabIconItem() 
	{
		return new ItemStack(ItemInit.RUBY);
	}
}
