package com.turtywurty.turtyutilities.objects.blocks.coloured;

import com.turtywurty.turtyutilities.objects.blocks.BlockBase;

import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;

public class BlockWhite extends BlockBase
{
	public BlockWhite(String name, Material material)
	{
		super(name, material);
        setSoundType(SoundType.CLOTH);
        setHardness(0.8f);
        setResistance(4.0f);
        setHarvestLevel("hand", -1);
        //setBlockUnbreakable();
	}
}
