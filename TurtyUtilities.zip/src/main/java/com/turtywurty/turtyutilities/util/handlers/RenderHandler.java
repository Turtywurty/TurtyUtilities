package com.turtywurty.turtyutilities.util.handlers;

import com.turtywurty.turtyutilities.entity.EntityFish;
import com.turtywurty.turtyutilities.entity.render.RenderFish;

import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.world.World;
import net.minecraftforge.fml.client.registry.IRenderFactory;
import net.minecraftforge.fml.client.registry.RenderingRegistry;

public class RenderHandler 
{
	public static void registerEntityRenderers()
	{
		RenderingRegistry.registerEntityRenderingHandler(EntityFish.class, new IRenderFactory<EntityFish>()
		{
			@Override
			public Render<? super EntityFish> createRenderFor(RenderManager manager) 
			{
				return new RenderFish(manager);
			}
		});
	}
}