package com.turtywurty.turtyutilities.objects.blocks;

import java.util.Random;

import com.turtywurty.turtyutilities.Main;
import com.turtywurty.turtyutilities.init.BlockInit;
import com.turtywurty.turtyutilities.init.ItemInit;
import com.turtywurty.turtyutilities.objects.blocks.item.ItemBlockVariants;
import com.turtywurty.turtyutilities.util.handlers.EnumHandler;
import com.turtywurty.turtyutilities.util.handlers.EnumHandler.EnumType;
import com.turtywurty.turtyutilities.util.interfaces.IHasModel;
import com.turtywurty.turtyutilities.util.interfaces.IMetaName;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;

public class BlockOres extends Block implements IHasModel, IMetaName
{
	public static final PropertyEnum<EnumHandler.EnumType> VARIANT = PropertyEnum.<EnumHandler.EnumType>create("variant", EnumHandler.EnumType.class);
	
	private String name, dimension;
	
	public BlockOres(String name, String dimension)
	{
		super(Material.ROCK);
		setUnlocalizedName(name);
		setRegistryName(name);
		setCreativeTab(Main.TURTYUTILITIESTAB);
		setHardness(3.0F);
		setHarvestLevel(ItemPickaxe.class, 2);
		
		this.name = name;
		this.dimension = dimension;
		
		BlockInit.BLOCKS.add(this);
		ItemInit.ITEMS.add(new ItemBlockVariants(this).setRegistryName(this.getRegistryName()));
	}

	private void setHarvestLevel(Class<ItemPickaxe> class1, int level) 
	{
		
	}
	
	@Override
    public int damageDropped(IBlockState state) 
    {
        EnumHandler.EnumType type = (EnumHandler.EnumType) state.getValue(VARIANT);
        return type == EnumHandler.EnumType.COPPER ? 0 : this.getMetaFromState(state);
    }
	
	public Item getItemDropped(IBlockState state, Random rand, int fortune)
    {
         if (this == BlockInit.ORE_END)
         {
             if (((EnumHandler.EnumType)state.getValue(VARIANT)) == EnumHandler.EnumType.SAPPHIRE)
             {
                 return ItemInit.SAPPHIRE;
             }
             
             else if (((EnumHandler.EnumType)state.getValue(VARIANT)) == EnumHandler.EnumType.RUBY)
             {
                 return ItemInit.RUBY;
             }
             
             else if (((EnumHandler.EnumType)state.getValue(VARIANT)) == EnumHandler.EnumType.AMETHYST)
             {
                 return ItemInit.AMETHYST;
             }
	      }
         
         if (this == BlockInit.ORE_NETHER)
         {
             if (((EnumHandler.EnumType)state.getValue(VARIANT)) == EnumHandler.EnumType.SAPPHIRE)
             {
                 return ItemInit.SAPPHIRE;
             }
             
             else if (((EnumHandler.EnumType)state.getValue(VARIANT)) == EnumHandler.EnumType.RUBY)
             {
                 return ItemInit.RUBY;
             }
             
             else if (((EnumHandler.EnumType)state.getValue(VARIANT)) == EnumHandler.EnumType.AMETHYST)
             {
                 return ItemInit.AMETHYST;
             }
         }
         
         if (this == BlockInit.ORE_OVERWORLD)
         {
             if (((EnumHandler.EnumType)state.getValue(VARIANT)) == EnumHandler.EnumType.SAPPHIRE)
             {
                 return ItemInit.SAPPHIRE;
             }
             
             else if (((EnumHandler.EnumType)state.getValue(VARIANT)) == EnumHandler.EnumType.RUBY)
             {
                 return ItemInit.RUBY;
             }
             
             else if (((EnumHandler.EnumType)state.getValue(VARIANT)) == EnumHandler.EnumType.AMETHYST)
             {
                 return ItemInit.AMETHYST;
             }
         }
         return null;
	     
	}
	   

	@Override
	public int getMetaFromState(IBlockState state) 
	{
		return ((EnumHandler.EnumType)state.getValue(VARIANT)).getMeta();
	}

	@Override
	public IBlockState getStateFromMeta(int meta) 
	{
		return this.getDefaultState().withProperty(VARIANT, EnumHandler.EnumType.byMetadata(meta));
	}

	@Override
	public ItemStack getPickBlock(IBlockState state, RayTraceResult target, World world, BlockPos pos, EntityPlayer player) 
	{
		return new ItemStack(Item.getItemFromBlock(this), 1, getMetaFromState(world.getBlockState(pos)));
	}

	@Override
	public void getSubBlocks(CreativeTabs itemIn, NonNullList<ItemStack> items)
	{
		for(EnumHandler.EnumType variant : EnumHandler.EnumType.values())
		{
			items.add(new ItemStack(this, 1, variant.getMeta()));
		}
	}

	@Override
	protected BlockStateContainer createBlockState()
	{
		return new BlockStateContainer(this, new IProperty[] {VARIANT});
	}

	@Override
	public String getSpecialName(ItemStack stack) 
	{
		return EnumHandler.EnumType.values()[stack.getItemDamage()].getName();
	}

	@Override
	public void registerModels() 
	{
		for(int i = 0; i < EnumHandler.EnumType.values().length; i++)
		{
			Main.proxy.registerVariantRenderer(Item.getItemFromBlock(this), i, "ore_" + this.dimension + "_" + EnumHandler.EnumType.values()[i].getName(), "inventory");
		}
	}
	
}
