package com.turtywurty.turtyutilities.objects.items.food;

import com.turtywurty.turtyutilities.Main;
import com.turtywurty.turtyutilities.init.ItemInit;
import com.turtywurty.turtyutilities.util.interfaces.IHasModel;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class EnchantedRubyApple extends ItemFood implements IHasModel
{
	public EnchantedRubyApple(String name, int amount, boolean isWolfFood) 
	{
		super(amount, isWolfFood);
		setUnlocalizedName(name);
		setRegistryName(name);
		setCreativeTab(Main.TURTYUTILITIESTAB);
		
		ItemInit.ITEMS.add(this);
	}
	
	
	 @SideOnly(Side.CLIENT)
	    public boolean hasEffect(ItemStack stack)
	    {
	        return true;
	    }
	@Override
    protected void onFoodEaten(ItemStack stack, World worldIn, EntityPlayer player)
    {
        if (!worldIn.isRemote)
        {
            	//Effect1
                player.addPotionEffect(new PotionEffect(MobEffects.HEALTH_BOOST, 1200, 2));
                
                //Effect2
                player.addPotionEffect(new PotionEffect(MobEffects.ABSORPTION, 1200, 14));
                
                //Effect3
                player.addPotionEffect(new PotionEffect(MobEffects.REGENERATION, 1100, 5));
        } 
    }
	
	@Override
	public void registerModels() 
	{
		Main.proxy.registerItemRenderer(this, 0, "inventory");
	}
}
