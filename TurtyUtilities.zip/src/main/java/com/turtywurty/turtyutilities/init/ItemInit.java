package com.turtywurty.turtyutilities.init;

import java.util.ArrayList;
import java.util.List;

import com.turtywurty.turtyutilities.objects.armour.ArmourBase;
import com.turtywurty.turtyutilities.objects.items.Backpack;
import com.turtywurty.turtyutilities.objects.items.GoldHeart;
import com.turtywurty.turtyutilities.objects.items.Heart;
import com.turtywurty.turtyutilities.objects.items.ItemBase;
import com.turtywurty.turtyutilities.objects.items.TomatoSeeds;
import com.turtywurty.turtyutilities.objects.items.food.EnchantedRubyApple;
import com.turtywurty.turtyutilities.objects.items.food.ItemModFood;
import com.turtywurty.turtyutilities.objects.items.food.TomatoSoup;
import com.turtywurty.turtyutilities.objects.tools.ToolAxe;
import com.turtywurty.turtyutilities.objects.tools.ToolHoe;
import com.turtywurty.turtyutilities.objects.tools.ToolPickaxe;
import com.turtywurty.turtyutilities.objects.tools.ToolShovel;
import com.turtywurty.turtyutilities.objects.tools.ToolSword;
import com.turtywurty.turtyutilities.util.Reference;

import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.Item.ToolMaterial;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraftforge.common.util.EnumHelper;

public class ItemInit 
{
	public static final List<Item> ITEMS = new ArrayList<Item>();
	
	//Materials
		public static final ToolMaterial TOOL_RUBY = EnumHelper.addToolMaterial("tool_ruby", 4, 1029, 5.0F, 3.5F, 17);
		public static final ArmorMaterial ARMOR_RUBY = EnumHelper.addArmorMaterial("armour_ruby", Reference.MOD_ID + ":ruby", 44, new int[] {4, 7, 9, 4}, 17, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 2.1F);
		
		public static final Item RUBY = new ItemBase("ruby");
		public static final Item SAPPHIRE = new ItemBase("sapphire");
		public static final Item TIN_INGOT = new ItemBase("tin_ingot");
		public static final Item OBSIDIAN_INGOT = new ItemBase("obsidian_ingot");
		public static final Item COPPER_INGOT = new ItemBase("copper_ingot");
		public static final Item SILVER_INGOT = new ItemBase("silver_ingot");
		public static final Item AMETHYST = new ItemBase("amethyst");
		public static final Item RUBY_APPLE = new ItemModFood("ruby_apple", 7, false);
		public static final Item ENCHANTED_RUBY_APPLE = new EnchantedRubyApple("enchanted_ruby_apple", 10, false);
		public static final Item TOMATO = new ItemModFood("tomato", 4, false);
		public static final Item TIN_NUGGET = new ItemBase("tin_nugget");
		public static final Item RUBY_CHUNK = new ItemBase("ruby_chunk");
		public static final Item OBSIDIAN_NUGGET = new ItemBase("obsidian_nugget");
		public static final Item SILVER_NUGGET = new ItemBase("silver_nugget");
		public static final Item COPPER_NUGGET = new ItemBase("copper_nugget");
		public static final Item TOMATO_SOUP = new TomatoSoup("tomato_soup", 9, false);	
		public static final Item TOMATO_SEEDS = new TomatoSeeds("tomato_seeds");
		public static final Item HEART = new Heart("heart");
		public static final Item BACKPACK = new Backpack("backpack");
		public static final Item GOLD_HEART = new GoldHeart("gold_heart");
		public static final Item URANIUM_INGOT = new ItemBase("uranium_ingot");
		
		//Tools
		public static final Item SWORD_RUBY = new ToolSword("sword_ruby", TOOL_RUBY);
		public static final Item PICKAXE_RUBY = new ToolPickaxe("pickaxe_ruby", TOOL_RUBY);
		public static final Item SHOVEL_RUBY = new ToolShovel("shovel_ruby", TOOL_RUBY);
		public static final Item AXE_RUBY = new ToolAxe("axe_ruby", TOOL_RUBY);
		public static final Item HOE_RUBY = new ToolHoe("hoe_ruby", TOOL_RUBY);
		
		//Armor
		public static final Item HELMET_RUBY = new ArmourBase("helmet_ruby", ARMOR_RUBY, 1, EntityEquipmentSlot.HEAD);
		public static final Item CHESTPLATE_RUBY = new ArmourBase("chestplate_ruby", ARMOR_RUBY, 1, EntityEquipmentSlot.CHEST);
		public static final Item LEGGINGS_RUBY = new ArmourBase("leggings_ruby", ARMOR_RUBY, 2, EntityEquipmentSlot.LEGS);
		public static final Item BOOTS_RUBY = new ArmourBase("boots_ruby", ARMOR_RUBY, 1, EntityEquipmentSlot.FEET);
}
