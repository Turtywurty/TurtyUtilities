package com.turtywurty.turtyutilities.objects.items.food;

import com.turtywurty.turtyutilities.Main;
import com.turtywurty.turtyutilities.init.ItemInit;
import com.turtywurty.turtyutilities.util.interfaces.IHasModel;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.EnumAction;
import net.minecraft.item.Item;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class TomatoSoup extends ItemFood implements IHasModel 
{
	public TomatoSoup(String name, int amount, boolean isWolfFood) 
	{
		super(amount, isWolfFood);
		setUnlocalizedName(name);
		setRegistryName(name);
		setCreativeTab(Main.TURTYUTILITIESTAB);
		
		ItemInit.ITEMS.add(this);
	}
	
	public EnumAction getItemUseAction(ItemStack stack)
    {
        return EnumAction.DRINK;
    }
	
	@Override
	public void registerModels() 
	{
		Main.proxy.registerItemRenderer(this, 0, "inventory");
	}
	
}
