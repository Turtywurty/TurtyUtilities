package com.turtywurty.turtyutilities.objects.tools;

import com.turtywurty.turtyutilities.Main;
import com.turtywurty.turtyutilities.init.ItemInit;
import com.turtywurty.turtyutilities.util.interfaces.IHasModel;

import net.minecraft.item.Item;
import net.minecraft.item.ItemSpade;
import net.minecraft.item.Item.ToolMaterial;

public class ToolShovel extends ItemSpade implements IHasModel 
{

	public ToolShovel(String name, ToolMaterial material) 
	{
		super(material);
		setUnlocalizedName(name);
		setRegistryName(name);
		setCreativeTab(Main.TURTYUTILITIESTAB);
		
		ItemInit.ITEMS.add(this);
	}
	
	@Override
	public void registerModels() 
	{
		Main.proxy.registerItemRenderer(this, 0, "inventory");
	}	
}

