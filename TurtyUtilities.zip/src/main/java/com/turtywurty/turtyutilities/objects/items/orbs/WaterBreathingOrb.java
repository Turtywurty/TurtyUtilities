package com.turtywurty.turtyutilities.objects.items.orbs;

import com.turtywurty.turtyutilities.Main;
import com.turtywurty.turtyutilities.init.ItemInit;
import com.turtywurty.turtyutilities.util.interfaces.IHasModel;

import ibxm.Player;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class WaterBreathingOrb extends Item implements IHasModel
{
	public WaterBreathingOrb(String name)
	{
		this.maxStackSize = 16;
		setUnlocalizedName(name);
		setRegistryName(name);
		setCreativeTab(Main.TURTYUTILITIESTAB);
		
		ItemInit.ITEMS.add(this);
	}
	
@Override
public ActionResult<ItemStack> onItemRightClick(World worldIn, EntityPlayer player, EnumHand handIn) 
{
	player.addPotionEffect(new PotionEffect(MobEffects.WATER_BREATHING, 1200, 2));
	player.getHeldItem(handIn).shrink(1);
	return super.onItemRightClick(worldIn, player, handIn);
}
	
	@Override
	public void registerModels() 
	{
		Main.proxy.registerItemRenderer(this, 0, "inventory");
	}
}
