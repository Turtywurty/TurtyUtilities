package com.turtywurty.turtyutilities.recipies;

import com.turtywurty.turtyutilities.init.BlockInit;
import com.turtywurty.turtyutilities.init.ItemInit;

import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class SmeltingRecipies
{
	public static void init()
	{
	
	}
	
}
